package com.example.eventosapp_pou;

import com.example.eventosapp_pou.model.Evento;
import com.example.eventosapp_pou.repository.EventoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class TesteMongo {
//    @Autowired
//    private EventoRepository repository;
//
//    public static void main(String[] args) {
//        SpringApplication.run(TesteMongo.class, args);
//    }
//
//
//
//    public void run(String... args) throws Exception {
//        System.out.print("CUUUUU");
//        // save a couple of customers
//        repository.save(new Evento("ashsdo", "sdhoadshds", "asiudsu", "hasdiuadhsiudhsad"));
//        repository.save(new Evento("Bob", "Smith", "assssss", "qqqq"));
//
//        // fetch all customers
//        System.out.println("Customers found with findAll():");
//        System.out.println("-------------------------------");
//        for (Evento customer : repository.findAll()) {
//            System.out.println(customer);
//        }
//        System.out.println();
//
//        // fetch an individual customer
//        System.out.println("Customer found with findByFirstName('Alice'):");
//        System.out.println("--------------------------------");
//        System.out.println(repository.findByName("Bob"));
//

}
